#!/bin/bash

# StarNote Example App - Folder Structure Setup
# Bu script example_app içinde çalıştırılmalı

echo "📁 StarNote App Structure Setup Starting..."

# Core directories
mkdir -p lib/core/constants
mkdir -p lib/core/database/tables
mkdir -p lib/core/di
mkdir -p lib/core/errors
mkdir -p lib/core/network
mkdir -p lib/core/routing
mkdir -p lib/core/theme
mkdir -p lib/core/utils

# Feature directories
mkdir -p lib/features/auth/data/datasources
mkdir -p lib/features/auth/data/models
mkdir -p lib/features/auth/data/repositories
mkdir -p lib/features/auth/domain/entities
mkdir -p lib/features/auth/domain/repositories
mkdir -p lib/features/auth/domain/usecases
mkdir -p lib/features/auth/presentation/providers
mkdir -p lib/features/auth/presentation/screens
mkdir -p lib/features/auth/presentation/widgets

mkdir -p lib/features/documents/data/datasources
mkdir -p lib/features/documents/data/models
mkdir -p lib/features/documents/data/repositories
mkdir -p lib/features/documents/domain/entities
mkdir -p lib/features/documents/domain/repositories
mkdir -p lib/features/documents/domain/usecases
mkdir -p lib/features/documents/presentation/providers
mkdir -p lib/features/documents/presentation/screens
mkdir -p lib/features/documents/presentation/widgets

mkdir -p lib/features/editor/presentation/providers
mkdir -p lib/features/editor/presentation/screens
mkdir -p lib/features/editor/presentation/widgets

mkdir -p lib/features/sync/data/datasources
mkdir -p lib/features/sync/data/repositories
mkdir -p lib/features/sync/domain/entities
mkdir -p lib/features/sync/domain/repositories
mkdir -p lib/features/sync/domain/usecases
mkdir -p lib/features/sync/presentation/providers
mkdir -p lib/features/sync/presentation/widgets

mkdir -p lib/features/premium/data/datasources
mkdir -p lib/features/premium/data/repositories
mkdir -p lib/features/premium/domain/entities
mkdir -p lib/features/premium/domain/repositories
mkdir -p lib/features/premium/domain/usecases
mkdir -p lib/features/premium/presentation/providers
mkdir -p lib/features/premium/presentation/screens
mkdir -p lib/features/premium/presentation/widgets

# Shared directories
mkdir -p lib/shared/widgets

# Test directories
mkdir -p test/core
mkdir -p test/features/auth/data/repositories
mkdir -p test/features/auth/domain/usecases
mkdir -p test/features/auth/presentation
mkdir -p test/features/documents/data/repositories
mkdir -p test/features/documents/domain/usecases
mkdir -p test/features/documents/presentation
mkdir -p test/features/editor
mkdir -p test/features/sync
mkdir -p test/features/premium
mkdir -p test/shared

echo "✅ Directory structure created!"
echo ""
echo "📄 Creating placeholder files..."

# Create .gitkeep files to preserve empty directories
find lib -type d -empty -exec touch {}/.gitkeep \;
find test -type d -empty -exec touch {}/.gitkeep \;

echo "✅ Setup complete!"
echo ""
echo "Next steps:"
echo "1. Add new dependencies to pubspec.yaml"
echo "2. Run 'flutter pub get'"
echo "3. Create core module files"
